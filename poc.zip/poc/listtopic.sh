sh /u01/kaf/kafka-3.1.0-src/bin/kafka-topics.sh --bootstrap-server=localhost:9092 --list
