CALL approve_loan(145,'GMBPXGhjscTkxrrbVsqNcaHrEEtSeApg');
