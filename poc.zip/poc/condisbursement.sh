sh /u01/kaf/kafka-3.1.0-src/bin/kafka-console-consumer.sh --topic disbursement --from-beginning --bootstrap-server localhost:9092
