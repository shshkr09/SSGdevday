nohup sh /u01/kaf/kafka-3.1.0-src/bin/zookeeper-server-start.sh config/zookeeper.properties &
nohup sh /u01/kaf/kafka-3.1.0-src//bin/kafka-server-start.sh config/server.properties &
